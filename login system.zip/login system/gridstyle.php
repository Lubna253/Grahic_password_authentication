<?php
@ include 'config.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
    <!-- <style> -->
    <!-- /* body {
        font-family: Arial, Helvetica;
    }

    .container {
        background: #eee;
        width: 700px;
        margin: 70px 0 0 50px;

        display: grid;
        grid-template-columns: 1fr 1fr 1fr;
        grid-template-rows: 150px 150px;

        grid-gap: 50px 30px;
    }

    .items1 {
        background: orangered;
        border-radius: 100%;

    }

    .items2 {
        background: yellowgreen;
        border-radius: 100%;
    }

    .items3 {
        background: blueviolet;
        border-radius: 100%;
    }

    .items4 {
        background: palevioletred;
        border-radius: 100%;
    }

    .items5 {
        background: royalblue;
        border-radius: 100%;
    }

    .items6 {
        background: olivedrab;
        border-radius: 100%;
    }

    form .container .reg-container .form-btn {
        background: #fbd0d9;
        color: crimson;
        text-transform: capitalize;
        font-size: 20px;
        cursor: pointer;
    }

    form .container .reg-container .form-btn:hover {
        background: crimson;
        color: #fff;
    } */ -->
    <!-- /* </style> */ -->
</head>

<body>

    <h1>Color Based Authentication</h1>

    <form action="login_form.php">
        <div class="container">
            <div class="items items1">First</div>
            <div class="items items2">Second</div>
            <div class="items items3">Third</div>
            <div class="items items4">Fourth</div>
            <div class="items items5">Fifth</div>
            <div class="items items6">Sixth</div>

            <div class="reg-container">
                <input type="submit" name="submit" value="register" class="form-btn">
            </div>
        </div>

    </form>


</body>

</html>